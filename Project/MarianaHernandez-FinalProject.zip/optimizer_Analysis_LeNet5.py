from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from torchinfo import summary
from torch import nn
import torch


# download data
train_dataset = datasets.MNIST(root="./datasets/", train=True, download=True,transform=transforms.ToTensor())
test_dataset = datasets.MNIST(root="./datasets/", train=False, download=True,transform=transforms.ToTensor())

#print the classes names 
classes = train_dataset.classes
print("Dataset Classes: ") 
print("\n".join(classes))

#get dimension of images
(img, label) = train_dataset[0] 
print(img.shape)

# Show images
torch.manual_seed(42)

fig = plt.figure(figsize=(16, 4))
rows,cols = 2,6

for i in range(1, rows * cols + 1):
    rand_ind = torch.randint(0,len(train_dataset),size = [1]).item()
    img, label = train_dataset[rand_ind]
    ax = fig.add_subplot(rows, cols, i)
    ax.imshow(img.squeeze(), cmap='gray')
    ax.set_title(classes[label])
    ax.axis("off")

plt.tight_layout()
plt.show()

#normalizing and standardizing data
imgs = torch.stack([img for img, _ in train_dataset], dim = 0)

mean = imgs.mean()
std = imgs.std()

print("Mean:", mean)
print("Standard Deviation:", std)

data_transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean = mean, std = std)])

train_dataset = datasets.MNIST(root="./datasets/", train=True, download=False,transform = data_transform)
test_dataset = datasets.MNIST(root="./datasets/", train=False, download=False,transform = data_transform)

BATCH_SIZE = 32

train = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=True)
test = DataLoader(dataset=test_dataset, batch_size=BATCH_SIZE, shuffle=False)

#LeNet5
class LeNet5(nn.Module):
    def __init__(self):
        super().__init__()

        self.features = nn.Sequential(
            nn.Conv2d(in_channels = 1, out_channels = 6, kernel_size = 5, padding = 2),
            nn.Tanh(),
            nn.AvgPool2d(kernel_size = 2, stride = 2),

            nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5),
            nn.Tanh(),
            nn.AvgPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Linear(16 * 5 * 5, 120),
            nn.Tanh(),
            nn.Linear(120, 84),
            nn.Tanh(),
            nn.Linear(84, 10),
        )

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

#Training set up
DEVICE = torch.device("cpu")
model = LeNet5().to(DEVICE)
criterion = nn.CrossEntropyLoss()

summary(model, input_size = (1,1, 28, 28))

def train_epoch(model, loader, optimizer, criterion):
    model.train()
    total_loss = 0.0
    correct = 0 
    total = 0

    for images, labels in loader:
        images, labels = images.to(DEVICE), labels.to(DEVICE)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        correct += predicted.eq(labels).sum().item()
        total   += labels.size(0)

    return total_loss / total, 100.0 * correct / total


def evaluate(model, loader, criterion):
    model.eval()
    total_loss= 0.0
    correct = 0 
    total = 0

    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            outputs = model(images)
            loss    = criterion(outputs, labels)

            total_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            correct += predicted.eq(labels).sum().item()
            total   += labels.size(0)

    return total_loss / total, 100.0 * correct / total

#optimizers set up
EPOCHS = 10
lr = 0.001

optimizers = {
    "SGD": lambda p: torch.optim.SGD(p , lr = lr, momentum = 0.9),
    "AdaGrad": lambda p: torch.optim.Adagrad(p , lr = lr),
    "RMSprop": lambda p: torch.optim.RMSprop(p , lr = lr),
    "Adam": lambda p: torch.optim.Adam(p , lr = lr), #wanted to test an optimizer I have used before
}

history = {
    name: {"train_loss": [], 
    "train_accuracy": [], 
    "test_loss":  [], 
    "test_accuracy":  []} 
    for name in optimizers
}

for opt_name, opt_fn in optimizers.items():
    print(f"Optimizer: {opt_name}")
    model = LeNet5().to(DEVICE)
    optimizer = opt_fn(model.parameters())

    for epoch in range(1, EPOCHS + 1):
        tr_loss, tr_acc = train_epoch(model, train, optimizer, criterion)
        te_loss, te_acc = evaluate(model, test, criterion)

        history[opt_name]["train_loss"].append(tr_loss)
        history[opt_name]["train_accuracy"].append(tr_acc)
        history[opt_name]["test_loss"].append(te_loss)
        history[opt_name]["test_accuracy"].append(te_acc)

        print(f"Epoch {epoch:2d}/{EPOCHS} | "
              f"Train Loss: {tr_loss:.4f} Accuracy: {tr_acc:.2f}% "
              f"Test Loss: {te_loss:.4f} Accuracy: {te_acc:.2f}%")

#ploting results
epochs_range = range(1, EPOCHS + 1)
colors = {"SGD": "red", "AdaGrad": "blue", "RMSprop": "green", "Adam": "orange"}

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle("LeNet-5 Optimizer Comparison — MNIST", fontsize=14, fontweight="bold")

for name, h in history.items():
    axes[0].plot(epochs_range, h["test_accuracy"],  label=name, color=colors[name], linewidth=2)
    axes[1].plot(epochs_range, h["test_loss"], label=name, color=colors[name], linewidth=2)

axes[0].set_title("Test Accuracy")
axes[0].set_xlabel("Epoch")
axes[0].set_ylabel("Accuracy (%)")

axes[1].set_title("Test Loss")
axes[1].set_xlabel("Epoch")
axes[1].set_ylabel("Loss")

for ax in axes:
    ax.legend()
    ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig("optimizer_comparison.png", dpi=150, bbox_inches="tight")
plt.show()

#summary
print(f"{'Optimizer':<12} {'Final Test Accuracy':>15} {'Final Test Loss':>16}")
print("-"*45)
for name, h in history.items():
    print(f"{name:<12} {h['test_accuracy'][-1]:>14.2f}%  {h['test_loss'][-1]:>15.4f}")
print("-"*45)